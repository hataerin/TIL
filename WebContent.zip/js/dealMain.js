class DealMain{
    constructor() {
        this.buttonSearch = $('#search');
        // this.buttonSearch.click(()=>{
        //     this.search();
        // });
        this.search();
        this.setCards();
        this.showInteresting();
    }
    
    setTableText = () => {
        this.tableEveryElement.addClass(" text-truncate");
        // $('tbody > *').css('data-toggle',"tooltip").css();
    }
    setCards = () => {
        const calHeight = $('.inputs_And_tables').css('height');
        const cards = $('.cards');
        cards.css('height', calHeight);
    }
    
    
    search = () => {
        // event.preventDefault();
        const tablepoints = $('tbody');
        tablepoints.on('click',(event)=>{
            // console.log(tablepoints, rowLength);
            let value = event.target.parentNode.dataset.value;
            if(value=="value"){
                const rows = $('tbody > tr');
                this.showModal(event, rows.length);
            }
            
        });
        this.tableEveryElement = $('tbody tr').add('tbody td').add('tbody th').add('thead tr').add('thead th');
        this.setTableText();
    }
    
    showModal = (event, len) => {
        console.log(event.target.parentNode, len);
        this.minimize(event.target.parentNode, len);
    }
    
    minimize = (val, len) => {
        const inputs = $('.inputs');
        const tables = $('.tables');
        const csses = $('.inputs *');
        // const test = csses.css('font-size');
        const inputAndTables = $('.inputs_And_tables');
        // if(test == "10px"){
            //     csses.css('font-size', 'inherit');
            // }
            // else {
                //     csses.css('font-size', '10px');
        // }
        inputs.toggleClass(" mx-auto");
        inputs.toggleClass(" text-truncate");
        // inputs.toggleClass("w-50");
        tables.toggleClass(" mx-auto");
        // tables.toggleClass("w-50");
        tables.toggleClass(" text-truncate");
        inputAndTables.toggleClass("w-50");
        this.toggleCard(val, len);
    }
    
    toggleCard = (val, len) => {
        const cards = $('.cards');
        const displayChange = $('#displayChange');
        console.log(len);
        const tablepoints = $('tbody > tr');
        let count = tablepoints.get();

        console.log(count);
        if(displayChange.css('display') != 'flex'){
            displayChange.css('display', 'flex');
            cards.css('display', 'flex');
            count.forEach((e, idx)=>{
                
                const card = $(`<div class="card">
                <div class="row">
                <div class="col-md-4">
                <img src="img/town.jpg" alt="..." style="width:100%;height:100%;object-fit:cover;">
                </div>
                <div class="col-md-8">
                <div class="card-body">
                <h5 class="card-title">${idx}</h5>
                
                
                </div>
                </div>
                </div>
                </div>`);
                const addPoint = card.find(".card-body"); 
                [...e.children].forEach((e1,idx1) =>{
                    console.log(e1.innerText);
                    addPoint.append(
                        $(`<p class="card-text">${e1.innerText}</p>`)
                    );
                });
                const time = new Date();
                card.append($(`<p class="card-text"><small class="text-muted">Last updated : ${time.getFullYear()}-${time.getMonth()+1}-${time.getDate()}</small></p>`));
                cards.append(card);
                
            })
            
        }
        else{
            cards.empty();
            displayChange.css('display', 'block');
        }
        
        
    }

    showInteresting = () => {
        this.interestingInfos = [1,2,3,4];
        const interestingArea = $('#interesting_Area1');
        const interestingAirPollution = $('#interesting_AirPollution');
        const infoTables = this.makeTables();
        const airTables = this.makeAirTables();
        interestingArea.click(()=>{
            let childWindow1 = window.open("interestingAreaPopUp.html" ,"관심지역_동네_정보!",
            
            "width=400,height=300,left=100,top=50");
            
            childWindow1.document.write(infoTables);
        });
        interestingAirPollution.click(()=>{
            let childWindow2 = window.open("interestingAirPollution.html", "관심지역_대기_오염_정보!",
            "width=400,height=300,left=100,top=50");    
            childWindow2.document.write(airTables);
        });
    
    }

    makeTables = () => {
       return `

       <style>
       table, tr, th, td{
            border: 1px solid black;
        }
       </style>
       <table>
            <caption>관심 있는 동네 업종</caption>
            <tr>
                <td> </td>
                <th scope="col">상권 위치</th>
                <th scope="col">업종</th>
                <th scope="col">매출</th>
                <th scope="col">행정동</th>
            </tr>
            <tr>
                <th scope="row">종로구</th>
                <td>서울</td>
                <td>한식</td>
                <td>2000000</td>
                <td>~~~동</td>
                </tr>
                <tr>
                <th scope="row">중랑구</th>
                <td>서울</td>
                <td>중식</td>
                <td>1500000</td>
                <td>~~~동</td>
                </tr>
                <tr>
                <th scope="row">서북구</th>
                <td>천안</td>
                <td>일식</td>
                <td>1000000</td>
                <td>~~~동</td>
                </tr>
        </table>

       `;
    }
    
    makeAirTables = () => {
        
        return `
        <style>
        table, tr, th, td{
             border: 1px solid black;
         }
        </style>
        <table>
             <caption>관심 있는 대기 오염 수치</caption>
             <tr>
                 <td> </td>
                 <th scope="col">초미세먼지</th>
                 <th scope="col">미세먼지</th>
                 <th scope="col">오존</th>
                 <th scope="col">이산화질소</th>
                 <th scope="col">일산화탄소</th>
                 <th scope="col">아황산가스</th>
             </tr>
             <tr>
                 <th scope="row">중구</th>
                 <td>19</td>
                 <td>30</td>
                 <td>0.039</td>
                 <td>0.020</td>
                 <td>0.4</td>
                 <td>0.003</td>
            </tr>
            <tr>
                 <th scope="row">성북구</th>
                 <td>17</td>
                 <td>25</td>
                 <td>0.030</td>
                 <td>0.027</td>
                 <td>0.6</td>
                 <td>0.003</td>
            </tr>
            <tr>
                 <th scope="row">노원구</th>
                 <td>19</td>
                 <td>24</td>
                 <td>0.038</td>
                 <td>0.017</td>
                 <td>0.5</td>
                 <td>0.003</td>
            </tr>
         </table>
    
        `;
    }
    
}

window.onload = () => {
    new DealMain();
}