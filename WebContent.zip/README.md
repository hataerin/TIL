# ✨7팀 2차 관통PJT✨


### 🗃️폴더구조

```
📁src
├── 📁css
│   ├── 📄index.css
│   ├── 📄signUp.css
│   └── 📄signIn.css
├── 📁js
│   ├── 📄index.js
│   ├── 📄signUp.js
│   └── 📄signIn.js
├── 📁img
├── 📄index.html
├── 📄signUp.html
├── 📄signIn.html
└── README.md
```

<br>